# Quest Business 🚀

> AI-Powered Business Growth for Small Businesses in India

**Live Site:** [questbusiness.in](https://questbusiness.in)

---

## What is Quest Business?

Quest Business helps small businesses in India stop competing on price and start winning on value — through websites, AI automation, WhatsApp systems, and positioning strategies that attract premium customers.

---

## Tech Stack

- **React 19** + TypeScript
- **Vite 7** — build tool
- **Tailwind CSS v3** — styling
- **shadcn/ui** — UI components (Radix UI)
- **GSAP** — animations
- **Lenis** — smooth scrolling
- **Sonner** — toast notifications

---

## Getting Started (Local Development)

### Prerequisites
- Node.js >= 18
- npm >= 9

### Install & Run

```bash
# Install dependencies
npm install

# Start dev server (opens at http://localhost:3000)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## Project Structure

```
quest-business/
├── public/                  # Static files (served as-is)
│   ├── logo.png             ← Your logo
│   ├── founder.png          ← Founder photo
│   ├── og-image.jpg         ← Social sharing image (1200×630px)
│   ├── robots.txt           ← SEO crawling rules
│   ├── sitemap.xml          ← Search engine sitemap
│   └── manifest.json        ← PWA manifest
├── src/
│   ├── sections/            ← Page sections (Hero, About, etc.)
│   ├── components/
│   │   └── ui/              ← shadcn/ui components
│   ├── hooks/               ← Custom React hooks
│   ├── types/               ← TypeScript type definitions
│   ├── App.tsx              ← Root component
│   ├── App.css              ← App-level styles
│   ├── index.css            ← Global styles
│   └── main.tsx             ← Entry point
├── index.html               ← HTML entry (has all SEO meta tags)
├── vercel.json              ← Vercel deployment config
├── vite.config.ts           ← Vite build config
├── tailwind.config.js       ← Tailwind theme config
├── tsconfig.json            ← TypeScript config
└── package.json             ← Dependencies & scripts
```

---

## Deployment

This project is deployed on **Vercel** with the custom domain `questbusiness.in`.

Every push to the `main` branch automatically triggers a new deployment.

### Manual Deploy Steps
1. Push changes to GitHub `main` branch
2. Vercel auto-detects and deploys in ~60 seconds
3. Visit [questbusiness.in](https://questbusiness.in) to confirm

---

## Contact

**Quest Business**
- 📧 vrk@questbusiness.in
- 📞 +91 70074 74846
- 🌐 [questbusiness.in](https://questbusiness.in)
